import * as THREE from '../node_modules/three/build/three.module.js';
import { Text } from '../node_modules/troika-three-text/dist/troika-three-text.esm.js';

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 0, 1000); 

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const myText = new Text()

myText.text = 'Hello world!';
myText.fontSize = 100;
myText.position.z = 200;
myText.color = '#FFFF00';
scene.add(myText)
myText.dispose();

