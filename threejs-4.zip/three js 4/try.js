import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.01, 1000);
const renderer = new THREE.WebGLRenderer({alpha:true});

const light = new THREE.AmbientLight( 0xffffff, 3 );
light.position.set( 0, 1, 0 ); 
light.castShadow = true; 
scene.add( light );

renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('thre').appendChild(renderer.domElement);
camera.position.z = 12;

const loader = new GLTFLoader();
let anime;
let bee;
loader.load('scene_converted.gltf',
    function ( gltf ) {
		 bee=gltf.scene;
		scene.add( bee );
		console.log(gltf.animations)

		anime=new THREE.AnimationMixer(bee);
		anime.clipAction(gltf.animations[0]).play();

	}
);

let arrposition =[
	{
		id:'banner',
		position:{x:0,y:-1,z:10},
		rotation:{x:0,y:1.5,z:0}
	},
	{
		id:'intro',
		position:{x:-5,y:-1,z:6},
		rotation:{x:0.5,y:1.5,z:0}
	},
	{
		id:'description',
		position:{x:7,y:-1,z:6},
		rotation:{x:0,y:-2,z:0}
	},
	{
		id:'contact',
		position:{x:0,y:-1,z:9},
		rotation:{x:0,y:1,z:0}
	}
];

function animate() {
    requestAnimationFrame(animate);
	if (anime) {
        anime.update(0.02); 
    }
    renderer.render(scene, camera);
}
const model_Move= ()=>{
	const sections = document.querySelectorAll('.section');
	let currentSection;
	sections.forEach((section)=>{
		const rect=section.getBoundingClientRect();
		if (rect.top<=window.innerHeight/3){
			currentSection=section.id;
		}

	});
	let position_active =arrposition.findIndex((val)=>val.id==currentSection);
	if(position_active>=0){
		let new_coordinate=arrposition[position_active];
		gsap.to(bee.position,{
			x: new_coordinate.position.x,
			y: new_coordinate.position.y,
			z: new_coordinate.position.z,
			duration:3,
			ease:"power1.out"

		});
		gsap.to(bee.rotation,{
			x: new_coordinate.rotation.x,
			y: new_coordinate.rotation.y,
			z: new_coordinate.rotation.z,
			duration:3,
			ease:"power1.out"
		})
		
	}
}
window.addEventListener('scroll',()=>{
	if(bee){
		model_Move();
	}})

animate();
window.addEventListener('resize',()=>{
	renderer.setSize(window.innerWidth, window.innerHeight);
	camera.aspect=window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
})