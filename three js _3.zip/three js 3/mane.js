import * as THREE from './three';
import { OrbitControls } from './three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from './three/addons/loaders/GLTFLoader.js';
import {RGBELoader} from './RGBELoader.js';


let object;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );




// const canva=document.querySelector('ddd');
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
// renderer.setSize( 665,400 );
renderer.setAnimationLoop( animate );

const axis=new THREE.AxesHelper();
axis.material.depthTest=false;
axis.renderOrder=1;
scene.add(axis);


document.getElementById("ddd").appendChild( renderer.domElement );
const controls = new OrbitControls( camera,renderer.domElement );

const loader = new GLTFLoader();
const loader2=new RGBELoader();

renderer.outputEncoding=THREE.sRGBEncoding;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=6;

loader2.load('free_1972_datsun_240k_gt/MR_INT-005_WhiteNeons_NAD.hdr',
	function(texture){
		texture.mapping=THREE.EquirectangularReflectionMapping;
		scene.environment=texture;
		loader.load('free_1972_datsun_240k_gt/scene.gltf',
			function(gltf){
				object =gltf.scene;
				object.position.set(-10,30,-50);
				// object.position.y=50;
				object.scale.set(3,3,3);
				scene.add(object);
			}
		 );
	})
//  const light1=new THREE.DirectionalLight()
//  const light = new THREE.AmbientLight();
//  scene.add(light1)
//  scene.add(light);
// renderer.setClearColor( 0xffffff, 0 );
 scene.background=new THREE.Color(0xeeeeee)
//  const groundgeometry=new THREE.PlaneGeometry(20,20,32,32);
// groundgeometry.rotateX(-Math.PI/2);
// groundgeometry.position.set(0,0,0);
// const groundmaterial=new THREE.MeshStandardMaterial({
// 	color:0xfffff,side:THREE.DoubleSide
// });
// const groundmesh=new THREE.Mesh(groundgeometry,groundmaterial);
// scene.add(groundmesh);

camera.position.set(5,0,5);
THREE.Controls.update();
function animate(time) {
	time*=0.001;
	renderer.render( scene, camera );
	// requestAnimationFrame(animate);
	// object.position.x=time;
	// object.position.y=time;
	// console.log(time)
	// object.position.z=time;
	
}