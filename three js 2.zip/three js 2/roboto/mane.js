import * as THREE from "three";
import {Text} from 'troika-three-text'


const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();

renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);
// Set scene background
scene.background = new THREE.Color( 0xff0000);
// Create the text object
const myText = new Text();
scene.add(myText);

// Set properties to configure
myText.text = 'good morning Addis Abeba!';
myText.fontSize = 2;
myText.position.z = -15;
myText.color = 0x9966FF;

// Set camera position
camera.position.z = 5;


// Render loop
function animate() {
    myText.rotation.x += 0.01;
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();